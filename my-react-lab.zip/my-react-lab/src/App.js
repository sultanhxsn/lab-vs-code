import React from "react";
import Navbar from "./Components/Navbar";
import LandingPage from "./Components/LandingPage";
import SpecialtyMenu from "./Components/SpecialtyMenu";
import Footer from "./Components/Footer";

function App() {
  const menuItems = [
    { title: "Spicy Chicken Wings", description: "Our signature spicy wings", price: 500 },
    { title: "Classic Fried Chicken", description: "Traditional recipe", price: 350 },
    { title: "Spicy Chicken Wings", description: "Our signature spicy wings", price: 650 },
  ];

  return (
    <div>
      <Navbar />
      <LandingPage />
      <SpecialtyMenu menuItems={menuItems} />
      <Footer />
    </div>
  );
}

export default App;

